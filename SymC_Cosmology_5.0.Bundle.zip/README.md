# SymC Cosmology — Major Revision Bundle

**Figures policy:** All plots are stored as **300 DPI PNG** for fast, cross‑platform rendering (Overleaf, arXiv preview, Zenodo thumbnails). 
The LaTeX preamble sets:
- `\graphicspath{{figs/}}` and `\DeclareGraphicsExtensions{.png,.pdf}`
- Use `\figinclude{fig_Rkz}{0.85\linewidth}` (omit extension).

If vector formats are required, drop matching `.pdf` files into `figs/` — LaTeX will prefer PNG and fall back to PDF automatically.
